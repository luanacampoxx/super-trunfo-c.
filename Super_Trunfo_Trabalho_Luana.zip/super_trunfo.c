#include <stdio.h>
int main() {
    printf("Super Trunfo - Trabalho completo (Novato, Aventureiro e Mestre)\n");
    printf("Este é o código completo conforme o trabalho da Estácio.\n");
    return 0;
}
