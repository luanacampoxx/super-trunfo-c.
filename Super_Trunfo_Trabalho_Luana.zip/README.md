# Trabalho - Desafio Lógica Super Trunfo

Este repositório contém o trabalho completo da disciplina **Introdução à Programação de Computadores**, da Estácio.

## Conteúdo

- `super_trunfo.c`: código-fonte em C implementando todos os níveis (Novato, Aventureiro e Mestre).

## Como compilar e executar

```bash
gcc -o super_trunfo super_trunfo.c -lm
./super_trunfo
```

## Autor
Luana Campos

